# usp-core-waap-operator

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.16.0](https://img.shields.io/badge/AppVersion-1.16.0-informational?style=flat-square)

A Helm chart for Kubernetes

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| envoyImage | string | `"quay.io/usp/usp-core-waap:1.1.0"` |  |
| image.registry | string | `"quay.io/usp/usp-core-waap-operator"` |  |
| operatorVersion | string | `"latest"` |  |

